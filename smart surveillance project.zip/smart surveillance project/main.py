import cv2
from datetime import datetime

from detector.motion_detector import MotionDetector
from detector.object_detector import ObjectDetector
from detector.face_recognizer import FaceRecognizer
from detector.plate_reader import PlateReader

from storage.database import Database
from storage.logger import Logger

def main():
    cap = cv2.VideoCapture(0)

    motion_detector = MotionDetector()
    object_detector = ObjectDetector()
    face_recognizer = FaceRecognizer()
    plate_reader = PlateReader()
    db = Database()
    logger = Logger()

    print("[INFO] Starting smart surveillance system...")

    while True:
        ret, frame = cap.read()
        if not ret:
            print("[ERROR] Failed to grab frame from camera.")
            break

        moved, frame_with_motion = motion_detector.detect(frame)
        if moved:
            detections, frame_with_objects = object_detector.detect(frame_with_motion)

            for det in detections:
                label = det['label']
                box = det['box']

                if label == 'person':
                    recognized_faces, frame_with_faces = face_recognizer.recognize(frame_with_objects)
                    for face in recognized_faces:
                        name = face['name']
                        left, top, right, bottom = face['box']
                        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

                        if name == "Unknown":
                            face_img = frame[top:bottom, left:right]
                            face_path = f"data/faces/face_{timestamp}.jpg"
                            cv2.imwrite(face_path, face_img)
                            db.insert_face(name, face_path, timestamp)
                            logger.log(f"Unknown face detected and saved: {face_path}")
                            print(f"[ALERT] Unknown face detected and saved.")

                elif label in ['car', 'truck', 'bus', 'motorbike']:
                    plate_number, plate_img_path = plate_reader.read_plate(frame_with_objects, box)
                    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")

                    if plate_number:
                        db.insert_plate(plate_number, plate_img_path, timestamp)
                        logger.log(f"Vehicle plate detected: {plate_number} saved at {plate_img_path}")
                        print(f"[INFO] Plate detected: {plate_number}")

        cv2.imshow("Smart Surveillance", frame_with_motion)

        if cv2.waitKey(1) & 0xFF == 27:
            print("[INFO] Exiting...")
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
