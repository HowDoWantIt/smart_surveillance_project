import sqlite3
import os

class Database:
    def __init__(self, db_path="data/logs/surveillance.db"):
        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        self.conn = sqlite3.connect(db_path)
        self._create_tables()

    def _create_tables(self):
        cur = self.conn.cursor()
        cur.execute("""
            CREATE TABLE IF NOT EXISTS faces (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT,
                image_path TEXT,
                timestamp TEXT
            )
        """)
        cur.execute("""
            CREATE TABLE IF NOT EXISTS plates (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                plate_number TEXT,
                image_path TEXT,
                timestamp TEXT
            )
        """)
        self.conn.commit()

    def insert_face(self, name, path, timestamp):
        self.conn.execute("INSERT INTO faces (name, image_path, timestamp) VALUES (?, ?, ?)",
                          (name, path, timestamp))
        self.conn.commit()

    def insert_plate(self, plate_number, path, timestamp):
        self.conn.execute("INSERT INTO plates (plate_number, image_path, timestamp) VALUES (?, ?, ?)",
                          (plate_number, path, timestamp))
        self.conn.commit()
