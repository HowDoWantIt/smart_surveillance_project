import pytesseract
import cv2
import re
import os
from datetime import datetime

class PlateReader:
    def __init__(self, output_dir="data/plates"):
        self.output_dir = output_dir
        os.makedirs(output_dir, exist_ok=True)

    def read_plate(self, frame, box):
        x1, y1, x2, y2 = box
        plate_img = frame[y1:y2, x1:x2]
        gray = cv2.cvtColor(plate_img, cv2.COLOR_BGR2GRAY)
        text = pytesseract.image_to_string(gray, config='--psm 8')
        plate_number = re.sub(r'[^A-Z0-9۰-۹ا-ی]', '', text.upper())
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename = os.path.join(self.output_dir, f"plate_{timestamp}.jpg")
        cv2.imwrite(filename, plate_img)
        return plate_number, filename
